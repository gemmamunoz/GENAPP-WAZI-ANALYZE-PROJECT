# cics-genapp

For instructions on provisioning GenApp on a 'fresh' zD&T as a Service system, see: [zD&T Install](https://github.ibm.com/IBMZSoftware/nazare-demo-genapp/edit/master/zdntinstall.md)
